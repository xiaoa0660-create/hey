# 照着拍 cowork 交接包

先读取 docs/cowork-handoff.md，末尾有可直接粘贴的任务提示词。
然后读取两版 PRD、交互设计图及关键手机截图。downloads 中是两份对应风格的用户手册。
本包是重建/评审材料，包含模型业务协议；不是可运行源码，也不包含 API Key。
完整源码在私有仓库 https://github.com/xiaoa0660-create/hey/tree/preview/mobile-v07-20261012 。读取源码需要授权，不能读取时先按本包重建并说明差异。
截图是现有实现参考；相机画面为受控测试视频，不能充当实体手机测试结果。
PRD 末尾少数 GitHub 外部链接需要有仓库访问权限。
